package main;

import game.Start;

public class Main
{
	public static void main(String[] args)
	{
		new Start().run();
	}
}